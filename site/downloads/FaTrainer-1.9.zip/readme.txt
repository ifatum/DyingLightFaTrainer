FaTrainer | Dying Light 1.9
===========================

In-game trainer menu for Dying Light. Press Insert or F8 in game.

Install (Windows)
  Copy xinput1_3.dll next to DyingLightGame.exe.

Install (Linux, Steam + Proton)
  Copy xinput1_3.dll next to DyingLightGame.exe and add to the Steam launch options:
  WINEDLLOVERRIDES="xinput1_3=n,b" %command%

Uninstall
  Delete xinput1_3.dll from the game folder.

Notes
  Back up your saves. Use cheats in co-op or PvP only with players who agree to it.
  Weapon edits apply to every weapon of that type until the game restarts.
  A dot in the sidebar marks pages with something turned on. "Turn all off" resets everything.
  Log file: fatrainer.log next to DyingLightGame.exe.

Source: https://github.com/ifatum/DyingLightFaTrainer (MIT)
